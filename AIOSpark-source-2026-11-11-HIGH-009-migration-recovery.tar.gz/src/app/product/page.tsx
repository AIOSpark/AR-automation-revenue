import { redirect } from "next/navigation";

export default function ProductPage() {
  redirect("/#product");
}
